/**
 * plugin javascript
 */
(function($){$(function () {				


});})(jQuery);